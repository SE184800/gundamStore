import { Headphones, Shield } from "lucide-react";
import Logo from "./Logo";
import { useLang } from "../../store/CmsStore";

const text = {
  vi: {
    footerDesc: "Gundam Store VN - Nơi đam mê được lắp ráp. Website bán Gunpla chính hãng, hàng sẵn, order và phụ kiện builder.",
    support: "Hỗ trợ", policies: "Chính sách", contact: "Liên hệ", orderLookup: "Tra cứu đơn", returnPolicy: "Chính sách đổi trả", preorderGuide: "Hướng dẫn Pre-order", privacy: "Bảo mật thông tin", payment: "Thanh toán", shipping: "Giao hàng", boxProtection: "Đóng gói bảo vệ hộp"
  },
  en: {
    footerDesc: "Gundam Store VN - Where passion is assembled. Authentic Gunpla, in-stock items, order items and builder accessories.",
    support: "Support", policies: "Policies", contact: "Contact", orderLookup: "Track order", returnPolicy: "Return policy", preorderGuide: "Pre-order guide", privacy: "Privacy policy", payment: "Payment", shipping: "Shipping", boxProtection: "Box protection packaging"
  }
};

export default function Footer() {
  const [lang] = useLang();
  const t = text[lang];
  return (
    <footer className="mt-4 border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-[1440px] gap-5 px-4 py-6 md:grid-cols-[1.2fr_0.8fr_0.8fr_0.8fr] lg:px-8">
        <div><Logo compact /><p className="mt-3 max-w-md text-xs leading-6 text-slate-500">{t.footerDesc}</p></div>
        <div><div className="mb-2 text-sm font-black text-slate-950">{t.support}</div><div className="space-y-1 text-xs text-slate-500"><div>{t.orderLookup}</div><div>{t.returnPolicy}</div><div>{t.preorderGuide}</div></div></div>
        <div><div className="mb-2 text-sm font-black text-slate-950">{t.policies}</div><div className="space-y-1 text-xs text-slate-500"><div>{t.privacy}</div><div>{t.payment}</div><div>{t.shipping}</div></div></div>
        <div><div className="mb-2 text-sm font-black text-slate-950">{t.contact}</div><div className="space-y-1 text-xs text-slate-500"><div className="flex items-center gap-2"><Headphones size={15} /> Messenger / Zalo</div><div className="flex items-center gap-2"><Shield size={15} /> {t.boxProtection}</div></div></div>
      </div>
    </footer>
  );
}
