import { Search, User, Home, Package, Gift, Newspaper, Phone, ShieldCheck } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useLang } from "../../store/CmsStore";
import Logo from "./Logo";

const copy = {
  vi: {
    search: "Tìm kiếm Gundam, Gunpla, Model Kit...",
    account: "Tài khoản",
    home: "Trang chủ",
    products: "Sản phẩm",
    preorder: "Pre-order",
    guide: "Hướng dẫn build",
    tracking: "Tra cứu đơn",
    sale: "Khuyến mãi",
    news: "Tin tức",
    contact: "Liên hệ",
    admin: "Admin",
  },
  en: {
    search: "Search Gundam, Gunpla, Model Kit...",
    account: "Account",
    home: "Home",
    products: "Products",
    preorder: "Pre-order",
    guide: "Build Guide",
    tracking: "Track Order",
    sale: "Promotions",
    news: "News",
    contact: "Contact",
    admin: "Admin",
  },
};

export default function Header() {
  const [lang, setLang] = useLang();
  const t = copy[lang] || copy.vi;
  const location = useLocation();

  const navItems = [
    { label: t.home, href: "/", icon: Home },
    { label: t.products, href: "/shop", icon: Package },
    { label: t.preorder, href: "/pre-order", icon: Gift },
    { label: t.sale, href: "/promotions", icon: Gift },
    { label: t.guide, href: "/build-guide", icon: ShieldCheck },
    { label: t.news, href: "#news", icon: Newspaper },
    { label: t.tracking, href: "/order-lookup", icon: Package },
    { label: t.contact, href: "#contact", icon: Phone },
    { label: t.admin, href: "/admin", icon: User },
  ]

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 shadow-sm backdrop-blur">
      <div className="mx-auto flex h-[64px] max-w-[1440px] items-center gap-3 px-4 lg:px-8">
        <a href="/" className="flex shrink-0 items-center">
          <Logo className="h-12 w-auto object-contain" />
        </a>

        <div className="mx-auto hidden w-full max-w-[620px] items-center rounded-2xl border border-slate-200 bg-white px-3 py-2 shadow-sm transition focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-100 md:flex">
          <Search size={22} className="text-blue-600" />
          <input
            className="w-full bg-transparent px-3 text-sm font-semibold outline-none placeholder:text-slate-400"
            placeholder={t.search}
          />
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="flex rounded-2xl border border-slate-200 bg-slate-50 p-1 shadow-sm">
            {["vi", "en"].map((item) => (
              <button
                key={item}
                onClick={() => setLang(item)}
                className={`rounded-xl px-4 py-2 text-xs font-black uppercase transition ${
                  lang === item
                    ? "bg-blue-700 text-white shadow-md"
                    : "text-slate-500 hover:bg-white hover:text-slate-900"
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          <a
            href="#account"
            className="hidden items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700 md:flex"
          >
            <User size={20} />
            {t.account}
          </a>
        </div>
      </div>

      <nav className="border-t border-slate-100 bg-gradient-to-r from-slate-50 via-white to-slate-50">
        <div className="mx-auto flex max-w-[1440px] items-center gap-2 overflow-x-auto px-4 py-2 lg:px-8">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.label}
                href={item.href}
                className={`group flex items-center gap-2 whitespace-nowrap rounded-2xl px-3 py-2 text-xs font-black transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-100 ${
                  (item.href === "/" ? location.pathname === "/" : location.pathname.startsWith(item.href.split("?")[0]))
                    ? "bg-blue-700 text-white shadow-lg shadow-blue-100"
                    : "text-slate-700 hover:bg-blue-700 hover:text-white"
                }`}
              >
                <Icon
                  size={16}
                  className={`transition ${
                    (item.href === "/" ? location.pathname === "/" : location.pathname.startsWith(item.href.split("?")[0]))
                      ? "text-white"
                      : "text-blue-600 group-hover:text-white"
                  }`}
                />
                {item.label}
              </a>
            );
          })}
        </div>
      </nav>
    </header>
  );
}
