import { useMemo, useState } from "react";
import PageShell from "../../components/common/PageShell";
import { useCms } from "../../store/CmsStore";
import {
  Clock3,
  ExternalLink,
  MapPin,
  Ticket,
  Users,
  Video,
} from "lucide-react";
import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const fallbackEvents = [
  {
    id: "event-1",
    type: "internal",
    mode: "offline",
    status: "Open Registration",
    title: "Gunpla Build Workshop",
    date: "2026-06-08",
    time: "14:00 - 17:00",
    location: "Gundam Store VN Studio",
    address: "Quận 1, TP.HCM",
    organizer: "Gundam Store VN",
    fee: "Miễn phí",
    slots: "24 slots",
    attendees: 18,
    lat: 10.7769,
    lng: 106.7009,
    desc: "Workshop thực hành cắt runner, xử lý nub mark, panel line và hoàn thiện mô hình cho người mới.",
    agenda: ["Tool cơ bản", "Xử lý nub mark", "Panel line", "Q&A cùng builder"],
    cta: "Đăng ký tham gia",
  },
  {
    id: "event-2",
    type: "external",
    mode: "offline",
    status: "Upcoming",
    title: "Bandai Hobby Showcase",
    date: "2026-06-16",
    time: "10:00 - 20:00",
    location: "Hobby Expo Hall",
    address: "Bangkok, Thailand",
    organizer: "Bandai / Community",
    fee: "Theo BTC",
    slots: "Public event",
    attendees: 120,
    lat: 13.7563,
    lng: 100.5018,
    desc: "Triển lãm mô hình, release mới và khu vực trưng bày Gunpla trong khu vực.",
    agenda: ["Showcase", "Display booth", "Community meetup"],
    cta: "Xem thông tin",
  },
  {
    id: "event-3",
    type: "internal",
    mode: "livestream",
    status: "Live Soon",
    title: "Livestream Pre-order Opening",
    date: "2026-07-05",
    time: "20:00 - 21:30",
    location: "YouTube / Facebook Live",
    address: "Online",
    organizer: "Gundam Store VN",
    fee: "Miễn phí",
    slots: "Online",
    attendees: 86,
    lat: 35.6762,
    lng: 139.6503,
    desc: "Livestream mở preorder, giới thiệu hàng mới, mini game voucher và hỏi đáp cùng collector.",
    agenda: ["Unbox hàng mới", "Mở preorder", "Mini game", "Q&A"],
    cta: "Xem livestream",
  },
];

function tone(event) {
  if (event.mode === "livestream") return "purple";
  if (event.mode === "online") return "cyan";
  if (event.type === "internal") return "blue";
  return "amber";
}

function toneClass(event) {
  return {
    blue: "bg-blue-50 border-blue-200 text-blue-700",
    amber: "bg-amber-50 border-amber-200 text-amber-700",
    cyan: "bg-cyan-50 border-cyan-200 text-cyan-700",
    purple: "bg-purple-50 border-purple-200 text-purple-700",
  }[tone(event)];
}

function markerColor(event) {
  return {
    blue: "#2563eb",
    amber: "#f59e0b",
    cyan: "#06b6d4",
    purple: "#a855f7",
  }[tone(event)];
}

function label(event) {
  if (event.mode === "livestream") return "Livestream";
  if (event.mode === "online") return "Online";
  if (event.type === "internal") return "Shop tổ chức";
  return "Bên ngoài";
}

function makeMarker(event, selectedId) {
  const color = markerColor(event);
  const active = event.id === selectedId;
  return L.divIcon({
    className: "",
    html: `
      <div style="
        width:${active ? 26 : 20}px;
        height:${active ? 26 : 20}px;
        border-radius:999px;
        background:${color};
        border:3px solid white;
        box-shadow:0 0 0 ${active ? 12 : 8}px ${color}33, 0 12px 28px rgba(15,23,42,.35);
      "></div>
    `,
    iconSize: [active ? 26 : 20, active ? 26 : 20],
    iconAnchor: [13, 13],
  });
}

function daysUntil(date) {
  const now = new Date("2026-06-01T00:00:00");
  const target = new Date(date);
  return Math.max(0, Math.ceil((target - now) / (1000 * 60 * 60 * 24)));
}

export default function EventsPage() {
  const { state } = useCms();

  const events = (state.events && state.events.length ? state.events : fallbackEvents)
    .filter((event) => event.active !== false)
    .map((event) => ({
      ...event,
      lat: Number(event.lat || 10.7769),
      lng: Number(event.lng || 106.7009),
      agenda: Array.isArray(event.agenda) ? event.agenda : [],
      attendees: Number(event.attendees || 0),
    }));

  const [month, setMonth] = useState(new Date(2026, 5, 1));
  const [selected, setSelected] = useState(events[0] || fallbackEvents[0]);

  const visibleEvents = useMemo(
    () =>
      events.filter((e) => {
        const d = new Date(e.date);
        return d.getFullYear() === month.getFullYear() && d.getMonth() === month.getMonth();
      }),
    [month]
  );

  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const firstDay = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const offset = firstDay === 0 ? 6 : firstDay - 1;
  const cells = Array.from({ length: offset + daysInMonth }, (_, i) => (i < offset ? null : i - offset + 1));

  function changeMonth(delta) {
    const next = new Date(month.getFullYear(), month.getMonth() + delta, 1);
    setMonth(next);
    const nextEvents = events.filter((e) => {
      const d = new Date(e.date);
      return d.getFullYear() === next.getFullYear() && d.getMonth() === next.getMonth();
    });
    if (nextEvents[0]) setSelected(nextEvents[0]);
  }

  return (
    <PageShell>
      <main className="mx-auto max-w-[1440px] px-4 py-8 lg:px-8">
        <section className="relative overflow-hidden rounded-[36px] bg-slate-950 p-8 text-white shadow-[0_30px_120px_rgba(15,23,42,0.25)]">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_30%,rgba(37,99,235,0.38),transparent_34%),radial-gradient(circle_at_20%_75%,rgba(168,85,247,0.32),transparent_30%)]" />
          <div className="relative z-10 grid gap-8 lg:grid-cols-[1fr_360px]">
            <div>
              <div className="inline-flex rounded-full bg-blue-700 px-4 py-2 text-xs font-black uppercase tracking-[0.25em]">
                Events Calendar
              </div>
              <h1 className="mt-5 text-5xl font-black leading-[0.95] md:text-7xl">
                Lịch sự kiện Gunpla
              </h1>
              <p className="mt-5 max-w-2xl text-base font-semibold leading-8 text-white/75">
                Workshop, contest, expo, online event và livestream cộng đồng cho builder/collector.
              </p>
            </div>

            <div className="rounded-[28px] border border-white/10 bg-white/10 p-5 backdrop-blur">
              <div className="text-xs font-black uppercase tracking-widest text-blue-200">Selected Event</div>
              <div className="mt-3 text-2xl font-black">{selected.title}</div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <MiniStat label="Starts in" value={`${daysUntil(selected.date)} ngày`} />
                <MiniStat label="Joining" value={`${selected.attendees}+`} />
              </div>
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-6 xl:grid-cols-[1fr_420px]">
          <section className="overflow-hidden rounded-[32px] border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-5">
              <div className="text-xs font-black uppercase tracking-[0.22em] text-blue-700">OpenStreetMap</div>
              <h2 className="mt-1 text-3xl font-black text-slate-950">Bản đồ sự kiện thật</h2>
              <p className="mt-2 text-sm font-semibold text-slate-500">
                Click marker để xem nhanh, chọn sự kiện để xem chi tiết bên phải.
              </p>
            </div>

            <div className="h-[500px] overflow-hidden rounded-[28px] border border-slate-200">
              <MapContainer center={[15, 105]} zoom={3} scrollWheelZoom={false} className="h-full w-full">
                <TileLayer
                  attribution='&copy; OpenStreetMap contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {events.map((event) => (
                  <Marker
                    key={event.id}
                    position={[event.lat, event.lng]}
                    icon={makeMarker(event, selected.id)}
                    eventHandlers={{
                      click: () => setSelected(event),
                    }}
                  >
                    <Popup>
                      <div style={{ minWidth: 220 }}>
                        <b>{event.title}</b>
                        <div>{event.location}</div>
                        <div>{event.date} • {event.time}</div>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>
          </section>

          <aside className="rounded-[32px] border border-slate-200 bg-white p-5 shadow-sm">
            <span className={`rounded-full border px-3 py-1 text-xs font-black uppercase ${toneClass(selected)}`}>
              {label(selected)}
            </span>
            <h2 className="mt-4 text-3xl font-black text-slate-950">{selected.title}</h2>
            <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">{selected.desc}</p>

            <div className="mt-5 grid gap-3">
              <Info icon={Clock3} label="Thời gian" value={`${selected.date} • ${selected.time}`} />
              <Info icon={MapPin} label={selected.location} value={selected.address} />
              <Info icon={Users} label="Organizer" value={selected.organizer} />
              <Info icon={Ticket} label="Thông tin" value={`${selected.fee} • ${selected.slots} • ${selected.status}`} />
            </div>

            {selected.mode === "livestream" && (
              <div className="mt-5 overflow-hidden rounded-2xl border border-purple-100 bg-slate-950">
                <div className="flex aspect-video items-center justify-center text-white">
                  <div className="text-center">
                    <Video className="mx-auto mb-3 text-purple-400" size={34} />
                    <div className="text-lg font-black">Livestream Embed Preview</div>
                    <div className="mt-1 text-xs font-semibold text-white/60">Nhúng YouTube/Facebook Live tại đây</div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-5 rounded-2xl bg-slate-50 p-4">
              <div className="text-xs font-black uppercase tracking-widest text-slate-400">Agenda</div>
              <div className="mt-3 space-y-2">
                {selected.agenda.map((item) => (
                  <div key={item} className="rounded-xl bg-white px-3 py-2 text-sm font-bold text-slate-700 shadow-sm">
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-3">
              <a
                href={`/news/events/${selected.id}`}
                className="rounded-2xl bg-blue-700 px-5 py-3 text-sm font-black text-white shadow-lg shadow-blue-100"
              >
                Xem chi tiết
              </a>
              <a
                href={`https://www.openstreetmap.org/?mlat=${selected.lat}&mlon=${selected.lng}#map=14/${selected.lat}/${selected.lng}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 px-5 py-3 text-sm font-black text-slate-700 hover:bg-slate-50"
              >
                <ExternalLink size={16} />
                Mở bản đồ
              </a>
            </div>
          </aside>
        </section>

        <section className="mt-8 rounded-[32px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-5 flex items-center justify-between gap-3">
            <button onClick={() => changeMonth(-1)} className="rounded-full border border-slate-200 px-4 py-3 text-sm font-black hover:bg-slate-50">‹ Tháng trước</button>
            <div className="text-center">
              <div className="text-xs font-black uppercase tracking-[0.22em] text-blue-700">
                {month.toLocaleString("vi-VN", { month: "long", year: "numeric" })}
              </div>
              <h2 className="mt-1 text-3xl font-black text-slate-950">Calendar Board</h2>
            </div>
            <button onClick={() => changeMonth(1)} className="rounded-full border border-slate-200 px-4 py-3 text-sm font-black hover:bg-slate-50">Tháng sau ›</button>
          </div>

          <div className="grid grid-cols-7 gap-2 text-center">
            {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map((d) => (
              <div key={d} className="py-2 text-xs font-black text-slate-400">{d}</div>
            ))}

            {cells.map((day, index) => {
              if (!day) return <div key={index} />;

              const hit = visibleEvents.find((e) => Number(e.date.split("-").pop()) === day);
              return (
                <button
                  key={day}
                  onClick={() => hit && setSelected(hit)}
                  className={`min-h-[92px] rounded-2xl border p-2 text-left transition ${
                    hit ? `${toneClass(hit)} hover:-translate-y-1 hover:shadow-lg` : "border-slate-100 bg-slate-50 text-slate-400"
                  }`}
                >
                  <div className="text-xs font-black">{day}</div>
                  {hit && <div className="mt-2 rounded-xl bg-white/80 p-2 text-[11px] font-black leading-4 shadow-sm">{hit.title}</div>}
                </button>
              );
            })}
          </div>
        </section>

        <section className="mt-8 rounded-[32px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <div className="text-xs font-black uppercase tracking-[0.22em] text-blue-700">Monthly Events</div>
              <h2 className="mt-1 text-3xl font-black text-slate-950">Sự kiện trong tháng</h2>
            </div>
            <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-blue-700">{visibleEvents.length} sự kiện</span>
          </div>

          {visibleEvents.length ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {visibleEvents.map((event) => (
                <button
                  key={event.id}
                  onClick={() => setSelected(event)}
                  className="group rounded-[26px] border border-slate-200 bg-slate-50 p-5 text-left transition hover:-translate-y-1 hover:border-blue-300 hover:bg-white hover:shadow-xl"
                >
                  <span className={`rounded-full border px-3 py-1 text-xs font-black uppercase ${toneClass(event)}`}>
                    {label(event)}
                  </span>
                  <h3 className="mt-4 text-xl font-black text-slate-950 group-hover:text-blue-700">{event.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm font-semibold leading-6 text-slate-600">{event.desc}</p>
                  <div className="mt-4 text-sm font-bold text-slate-500">{event.date} • {event.time}</div>
                  <div className="mt-4 text-sm font-black text-blue-700">Xem chi tiết →</div>
                </button>
              ))}
            </div>
          ) : (
            <div className="rounded-[24px] bg-slate-50 p-8 text-center">
              <div className="text-lg font-black text-slate-950">Chưa có sự kiện trong tháng này</div>
              <div className="mt-2 text-sm font-semibold text-slate-500">Hãy chuyển tháng khác hoặc theo dõi cập nhật mới.</div>
            </div>
          )}
        </section>
      </main>
    </PageShell>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="rounded-2xl bg-white/10 p-4">
      <div className="text-xs font-black uppercase text-white/50">{label}</div>
      <div className="mt-1 text-2xl font-black">{value}</div>
    </div>
  );
}

function Info({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <div className="flex items-center gap-2 text-xs font-black uppercase text-slate-400">
        <Icon size={15} />
        {label}
      </div>
      <div className="mt-1 text-sm font-black text-slate-800">{value}</div>
    </div>
  );
}
